import java.sql.*;
public class Retrieve {

    static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
    static final String QUERY = "select * from employee";
    
    
	public static void main(String[] args) {
		
		 try(
		           Connection con = DriverManager.getConnection(D_URL, USER, PASS);
		           Statement stmt = con.createStatement();
		           ResultSet rs = stmt.executeQuery(QUERY);){

		           while(rs.next()){
		               System.out.println("Employee ID : " + rs.getInt("emp_id"));
		               System.out.println("Employee NAME : "+ rs.getString("emp_name"));
		               System.out.println("Employee ADDRESS : "+ rs.getString("emp_address"));
		               System.out.println("Employee City : "+ rs.getString("emp_city"));
		           }


		        }catch(SQLException e){

		       }

		
	}

}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.Scanner;

public class Insert {
	
    static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
    static final String QUERY = "insert into employee (emp_id,emp_name,emp_address,emp_city) values(?,?,?,?);";
    
    
	public static void main(String[] args) {
		
		 try(
		           Connection con = DriverManager.getConnection(D_URL, USER, PASS);
		           Statement stmt = con.createStatement();
				   PreparedStatement ps = con.prepareStatement(QUERY);){
			 
			 Scanner sc = new Scanner(System.in);
			 System.out.println("Enter EMP_ID :");
			 int id = sc.nextInt();
			 System.out.println("Enter EMP_NAME :");
			 String name = sc.next();
			 System.out.println("Enter EMP_ADDRESS :");
			 String address = sc.next();
			 System.out.println("Enter EMP_CITY :");
			 String city = sc.next();
			 
			 ps.setInt(1, id);
			 ps.setString(2, name);
			 ps.setString(3, address);
			 ps.setString(4, city);
			 ps.executeUpdate();
	
		 }catch(SQLException e){

		       }
	

}
}

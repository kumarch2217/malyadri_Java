import java.sql.*;
import java.util.Scanner;
public class Update {
	
    static final String D_URL = "jdbc:mysql://localhost:3306/democog";
    static final String USER = "root";
    static final String PASS = "pass@word1";
    static final String QUERY = "update employee set emp_name = ? where emp_id = ?;";

	public static void main(String[] args) {
		
		try(
		           Connection con = DriverManager.getConnection(D_URL, USER, PASS);
		           Statement stmt = con.createStatement();
		           PreparedStatement ps = con.prepareStatement(QUERY);){
			
						Scanner sc = new Scanner(System.in);
			
						System.out.println("Enter the name of Employee to be updated : ");
						String name = sc.next();
						System.out.println("Enter the employee ID who needs an update");
						int id = sc.nextInt();
						
						ps.setString(1, name);
						ps.setInt(2, id);
						
						ps.executeUpdate();
						
		           


		        }catch(SQLException e){

		       }

	}

}
